//
//  CalculatorBrain.swift
//  Calculator
//
//  Created by Umair Sultan on 18/06/2025.
//

import Foundation

func changeSign(operand: Double)-> Double{
    
    return -operand
    
}

struct CalculatorBrain{
    
    private var accumulator: Double?
    
    enum Operation {
        
        case constant(Double)
        
        case unaryOperation((Double)-> Double)
        
        case binaryOperation((Double, Double)-> Double)
        
        case equals
        
        
    }
    
    
    private var operations: Dictionary <String,Operation> = [
    
        "π": .constant (Double.pi),
        
        "e": .constant (M_E),
        
        "√": .unaryOperation (sqrt),
        
        "cos": .unaryOperation (cos),
        
        "+/-": .unaryOperation (changeSign),
        
        "+": .binaryOperation {$0 + $1},
        
        "-": .binaryOperation {$0 - $1},
        
        "x": .binaryOperation {$0 * $1},
        
        "/": .binaryOperation {$0 / $1},
        
        "=": .equals
        
    ]
    
  mutating  func performOperation(_ symbol:String){
      
      if let constant = operations[symbol]{
          
          switch constant{
              
          case .constant(let value):
              
              accumulator = value
              
          case .unaryOperation(let function):
              
              if accumulator != nil{
                  
                  accumulator = function(accumulator!)
                  
              }
              
          case .binaryOperation(let function):
              
              if accumulator != nil
              {
                  pbo = PendingBinaryOperation(function: function, firstOperand: accumulator!)
                  
                  accumulator = nil
                  
              }
              
          case .equals:
              
             PerformPendingBinaryOperation()
              
          }

     }

}
    private mutating func PerformPendingBinaryOperation(){
        
        if pbo != nil && accumulator != nil{
            
            accumulator = pbo!.perforn(with: accumulator!)
            
        }
    }
    
    private var pbo : PendingBinaryOperation?
    
    private struct PendingBinaryOperation {
        
        var function : (Double,Double)->Double
        
        var firstOperand: Double
        
        func perforn(with secondOperand: Double)->Double{
            
            return function(firstOperand,secondOperand)
            
        }
    }

    mutating func setOperand(_ operand:Double){
        
        accumulator = operand
        
    }
    
    var result:Double?{
        
        get{
            
            return accumulator
            
        }
        
    }
    
    
}
