//
//  ViewController.swift
//  Calculator
//
//  Created by Admin on 18/06/2025.
//

import UIKit

class ViewController: UIViewController{
    
    // for Label
    
    @IBOutlet weak var display: UILabel?
    
    var userinmiddleoftyping: Bool = false
    
    // for Keypad Digits
    
    
    @IBAction func touchDigit(_ sender: UIButton) {
        
        let digit = sender.currentTitle
        
        print("\(digit!) was Pressed")
        
        // now print the digit pressed in label
        
        if userinmiddleoftyping {
            
            let textcurrentlyindisplay =
            display!.text!
            
            display!.text =
            
            textcurrentlyindisplay + digit!
            
        }
        
        else{
          
            display!.text! = digit!
            
            userinmiddleoftyping = true
        }
        
    }
    
    

    
    var DisplayValue: Double{
        
        get{
            
            return Double(display!.text!)!
            
            }
        
        set{
            
            display!.text = String(newValue)
            
        }
    }
    
private var brain = CalculatorBrain()
    
    @IBAction func performOperation(_ sender: UIButton) {
        
        if userinmiddleoftyping{
            
            brain.setOperand(DisplayValue)
            
                  userinmiddleoftyping = false
            
              }
              
              if let mathematicalSymbol = sender.currentTitle{
                  
                  brain.performOperation(mathematicalSymbol)
                  
              }
              
              if let result = brain.result{
                  
                  DisplayValue = result
                  
              }


    }
    
    
}
